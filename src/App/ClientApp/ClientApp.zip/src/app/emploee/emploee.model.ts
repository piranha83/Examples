export class EmploeeModel {
    id: number = 0;
    firstName: string = '';
    lastName: string = '';
    salary: number = 0;
    fullName: string = '';
    departmentId?: number;    
}
